<div class="nk-sidebar">           
            <div class="nk-nav-scroll">
                <ul class="metismenu" id="menu">
                        <li class="nav-label">
							<u><?php echo $this->session->userdata('username'); ?> - 
                        	<?php echo $this->session->userdata('role'); ?></u> <?php if($this->session->userdata('business')!=""){ ?>( <?php echo $this->session->userdata('business');?> ) <?php } ?>
                        </li>
                         <!--menu for TSO-->
                            <?php if ($this->session->userdata('role') == "TSO"){  ?>
                        <li>
                            <a class="distributor_form" href="<?php echo base_url(); ?>tso/distributor_form">
                                <i class="icon-note menu-icon"></i><span class="nav-text">New SubD Form</span>
                            </a>
                        </li>
                        <li>
                            <a class="entered_form" href="<?php echo base_url(); ?>tso/entered_form">
                                <i class="icon-menu menu-icon"></i><span class="nav-text">Entered Forms</span>
                            </a>
                        </li>
                        <li>
                            <a class="funneled_form" href="<?php echo base_url(); ?>tso/funneled_form_view">
                                <i class="fa fa-filter"></i><span class="nav-text">Funnel Form</span>
                            </a>
                        </li>
                         <?php } ?>
                         <!--menu for TSO-->

                         <!-- menu for SM -->
                         <?php if ($this->session->userdata('role') == "SM"){  ?>
                        <li>
                            <a class="distributor_form" href="<?php echo base_url(); ?>sm/distributor_form">
                                <i class="icon-note menu-icon"></i><span class="nav-text">New SubD Form</span>
                            </a>
                        </li>
                        <li>
                            <a class="entered_form" href="<?php echo base_url(); ?>sm/entered_form">
                                <i class="icon-menu menu-icon"></i><span class="nav-text">Entered Forms</span>
                            </a>
                        </li>
                        <li>
                            <a class="funneled_form" href="<?php echo base_url(); ?>sm/funneled_form_view">
                                <i class="fa fa-filter"></i><span class="nav-text">Funnel Form</span>
                            </a>
                        </li>
                         <?php } ?>
                         <!-- end menu for SM -->
                         
                        <!--menu for ASM-->
                        <?php if ($this->session->userdata('role') == "ASM"){  ?>
                        <li>
                            <a class="entered_form" href="<?php echo base_url(); ?>asm/entered_form">
                                <i class="icon-menu menu-icon"></i><span class="nav-text">Entered Forms</span>
                            </a>
                        </li>
                        <li>
                            <a class="rejected_form" href="<?php echo base_url(); ?>asm/rejected_form">
                                <i class="icon-ban menu-icon"></i><span class="nav-text">Future Prospects Forms</span>
                            </a>
                        </li>
                        <li>
                            <a class="approved_form" href="<?php echo base_url(); ?>asm/approved_form">
                                <i class="icon-check menu-icon"></i><span class="nav-text">Approved Forms</span>
                            </a>
                        </li>

                        <li>
                            <a class="funneled_form" href="<?php echo base_url(); ?>asm/funneled_form_view">
                                <i class="fa fa-filter"></i><span class="nav-text">Funnel Form</span>
                            </a>
                        </li>
                        <?php } ?>
                        <!--menu for ASM-->
                        <!-- menu for ZSM -->
                        <?php if ($this->session->userdata('role') == "ZSM"){  ?>
                        <li>
                            <a class="entered_form" href="<?php echo base_url(); ?>zsm/entered_form">
                                <i class="icon-menu menu-icon"></i><span class="nav-text">Entered Forms</span>
                            </a>
                        </li>
                        <li>
                            <a class="rejected_form" href="<?php echo base_url(); ?>zsm/rejected_form">
                                <i class="icon-ban menu-icon"></i><span class="nav-text">Future Prospects Forms</span>
                            </a>
                        </li>
                        <li>
                            <a class="approved_form" href="<?php echo base_url(); ?>zsm/approved_form">
                                <i class="icon-check menu-icon"></i><span class="nav-text">Approved Forms</span>
                            </a>
                        </li>

                        <li>
                            <a class="funneled_form" href="<?php echo base_url(); ?>zsm/funneled_form_view">
                                <i class="fa fa-filter"></i><span class="nav-text">Funnel Form</span>
                            </a>
                        </li>
                        <?php } ?>
                        <!-- end menu for ZSM -->
                        <!-- menu for Leader -->
                        <?php if ($this->session->userdata('role') == "LEADER"){  ?>
                        <li>
                            <a class="approved_form" href="<?php echo base_url(); ?>leader/approved_form">
                                <i class="icon-check menu-icon"></i><span class="nav-text">Approved Forms</span>
                            </a>
                        </li>
                        <li>
                            <a class="rejected_form" href="<?php echo base_url(); ?>leader/rejected_form">
                                <i class="icon-ban menu-icon"></i><span class="nav-text">Future Prospects Forms</span>
                            </a>
                        </li>

                        <li>
                            <a class="funneled_form" href="<?php echo base_url(); ?>leader/funneled_form_view">
                                <i class="fa fa-filter"></i><span class="nav-text">Funnel Form</span>
                            </a>
                        </li>

                         <?php } ?>
                         <!-- end menu for Leader -->
                         <!-- menu for VA -->
                         <?php if ($this->session->userdata('role') == "VA"){  ?>
                        <li>
                            <a class="asm_approved_form" href="<?php echo base_url(); ?>va/asm_approved_form">
                                <i class="icon-check menu-icon"></i><span class="nav-text">ASM Approved Forms</span>
                            </a>
                        </li>
                        <li>
                            <a class="approved_form" href="<?php echo base_url(); ?>va/reviewed_form">
                                <i class="icon-check menu-icon"></i><span class="nav-text">Reviewed Forms</span>
                            </a>
                        </li>
                        
                        
                        <!-- <li>
                            <a class="funneled_form" href="<?php echo base_url(); ?>va/funneled_form_view">
                                <i class="fa fa-filter"></i><span class="nav-text">Funneled Form</span>
                            </a>
                        </li> -->
                         <?php } ?>
                         <!-- menu for VA -->

                         <li>
                        	<a href="<?php echo base_url(); ?>common/change_password"><i class="icon-lock"></i> <span class="nav-text">Change Password</span></a>
                          </li>
                         
                        <li>
                        	<a href="<?php echo base_url(); ?>LoginController/logout"><i class="icon-key"></i> <span class="nav-text">Logout</span></a>
                          </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>


        