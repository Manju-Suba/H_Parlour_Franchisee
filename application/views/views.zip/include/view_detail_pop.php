<button type="button" class="btn btn-primary" data-toggle="modal" id="detail_view_trigger" data-target="#detailview" style="display:none;">View</button>

 <!-- image Modal --> 
 <div class="modal fade" id="detailview">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Additional Information</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body" style="padding-top:0;">
                    <div class="row" style="padding:12px 0;">
                        <div class="col-4" >latitude: <p id="pop_latitude"></p></div>
                        <div class="col-4" >longitude: <p id="pop_longitude"></p></div>
                        <div class="col-4" >Business: <p id="pop_business"></p></div>
                    </div>
                                                
                    <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                        <div class="col-4">Parameters</div>
                        <div class="col-4">Slab</div>
                        <div class="col-2">TSO Points</div>
                        <!-- <div class="col-2">VA Points</div> -->
                    </div>
                    <div class="row" style="padding:8px 0; background:#fff;">
                        <div class="col-4">No. of Years of exp. In Distribution</div>
                        <div class="col-4" id="pop_dist"></div>
                        <div class="col-2" id="pop_yo_ex"></div>
                                                    
                    </div>
                    <div class="row" style="padding:8px 0; background:#f3f3f3;">
                        <div class="col-4">Existing Company Business</div>
                        <div class="col-4" id="pop_get_bus_slab"></div>
                        <div class="col-2" id="pop_exis_com"></div>
                    </div>
                    <div class="row" style="padding:8px 0; background:#fff;">
                        <div class="col-4">Investment Capacity</div>
                        <div class="col-4" id="pop_get_cap_slab"></div>
                        <div class="col-2" id="pop_invest"></div>
                    </div>
                    <div class="row" style="padding:8px 0; background:#f3f3f3;">
                        <div class="col-4">Son of the Soil</div>
                        <div class="col-4" id="pop_soil_slab"></div>
                        <div class="col-2" id="pop_sos"></div>
                    </div>
                    <div class="row" style="padding:8px 0; background:#fff;">
                        <div class="col-4">Vehicle</div>
                        <div class="col-4" id="pop_vehi_slab"></div>
                        <div class="col-2" id="pop_vehicle"></div>
                    </div>
                    <div class="row" style="padding:8px 0; background:#f3f3f3;">
                        <div class="col-4">Godown</div>
                        <div class="col-4" id="pop_godown_slab"></div>
                        <div class="col-2" id="pop_godown"></div>
                    </div>
                    <div class="row" style="padding:8px 0; background:#fff;">
                        <div class="col-4">Remark</div>
                        <div class="col-8" id="pop_remark"></div>
                    </div>
                    <div class="row" style="padding:8px 0; background:#fff;">
                        <div class="col-4">ASM Remark</div>
                        <div class="col-8" id="pop_asm_remark"></div>
                    </div>
                                                
                    <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                        <div class="col-4">SS Code</div>
                        <div class="col-4">RSP (SSFA Number)</div>
                        <div class="col-4">Type of SubD</div>
                    </div>
                    <div class="row" style="padding:12px 0; background:#fff;">
                        <div class="col-4" id="pop_ss"></div>
                        <div class="col-4" id="pop_rstssta"></div>
                        <div class="col-4" id="pop_swd"></div>
                    </div>
                                                
                    <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                        <div class="col-2">State</div>
                        <div class="col-2">City</div>
                        <div class="col-2">Town</div>
                        <div class="col-2">Pin Code</div>
                        <div class="col-2">Population</div>
                        <div class="col-2">Town Code</div>
                    </div>
                    <div class="row" style="padding:12px 0; background:#fff;">
                        <div class="col-2" id="pop_state"></div>
                        <div class="col-2" id="pop_city"></div>
                        <div class="col-2" id="pop_town"></div>
                        <div class="col-2" id="pop_zip"></div>
                        <div class="col-2" id="pop_population"></div>
                        <div class="col-2" id="pop_town_code"></div>
                    </div>
                                                    
                    </div>
                </div>
            </div>
        </div>
    <!-- image Modal ends -->