<button type="button" class="btn btn-primary" data-toggle="modal" id="asm_image_view_trigger" data-target="#asm_imageview" style="display:none;">View</button>

 <!-- image Modal --> 
    <div class="modal fade" id="asm_imageview">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">ASM Images</h5>
            <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
            </button> 
        </div>
        <div class="modal-body">
          <div class="bootstrap-carousel">
            <div id="asm_img_pop_carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
        
                                                    
        
                                                
                    <a class="carousel-control-prev" href="#carouselExampleControls" data-slide="prev"><span class="carousel-control-prev-icon"></span> <span class="sr-only">Previous</span> </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" data-slide="next"><span class="carousel-control-next-icon"></span> <span class="sr-only">Next</span></a>
                </div>
            </div>
        </div>
        </div>
    </div>
    </div>
    </div>
    <!-- image Modal ends -->