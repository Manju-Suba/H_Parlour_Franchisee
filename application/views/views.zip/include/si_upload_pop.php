<button type="button" class="btn btn-primary" id="upload_inv_num_file_trigger" data-toggle="modal" style="display:none;" data-target="#upload_inv_num_file_Modal">
    <i class="fa fa-upload" aria-hidden="true"></i>&nbsp;Upload</button>

        <!-- Modal -->
        <div class="modal fade" id="upload_inv_num_file_Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="border-bottom: 0px solid #e5e5e5;">
                        <h5 class="modal-title" id="exampleModalLabel">Upload FIle with Distributor Code Details</h5>
                        <button type="button" class="close pop_close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body" style="text-align: center;">
                        <form name="consolidate_excel_upload_form" id="excel_upload_form"  action="javascript:void(0)"  method="post" enctype="multipart/form-data"  class="" >
                            
                            <div class="form-group mt-lg">
                                <label class="col-sm-3 control-label">Upload Excel</label>
                                <div class="col-sm-9">
                                    <input type="file" name="do_uploadFile" id="do_uploadFile" class="form-control" required >
                                </div>
                            </div>
                            <div class="form-group ">
                            <button type="submit" class="btn btn-primary" id="upload_confirm">Upload</button>
                            </div>
                        </form>
                        <b id="status_u_resp" style="display:none;"></b>
                    </div>
                    <div class="modal-footer" style="border-top: 0px solid #e5e5e5;">
                        <button type="button" class="btn btn-secondary pop_close" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
