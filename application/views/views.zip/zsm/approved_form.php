<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>CK_SubD Entered Form</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo asset_url();?>images/logo.png">
    <!-- Custom Stylesheet -->
    <link href="<?php echo asset_url();?>plugins/toastr/css/toastr.min.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>plugins/jquery-steps/css/jquery.steps.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>css/style.css" rel="stylesheet">
    
    <?php include('application/views/include/select_2_head.php'); ?>
     <style>
		/*.nav-header .brand-logo a{ padding:0;}
		.nav-header .brand-logo a b img{ max-width:100%;}
		[data-sidebar-style="full"][data-layout="vertical"] .menu-toggle .nav-header .brand-logo a{ padding:0;}
		[data-nav-headerbg="color_1"] .nav-header{background-color:#fff;}
		.wizard > .steps > ul > li{ width:30%;}
		.wizard .content{ min-height:500px !important;}*/
		.card .card-body {    padding:0 0 1.88rem 0;}
	</style>

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
         <?php include('application/views/include/header.php'); ?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
         <?php include('application/views/include/sidebar.php'); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
               
            </div>
            <!-- row -->
            
            <!-- start: alert Message -->
                    <?php $message = $this->session->flashdata('message'); ?>
                    <?php $error = $this->session->flashdata('error'); ?>
                    <?php if (!empty($message)): ?>
                    	<div id="toast-container" class="toast-top-center">
                        	<div class="toast toast-success" aria-live="polite" style="">
                                <button type="button" class="toast-close-button" role="button">×</button>
                                <div class="toast-title">Distributor</div>
                                <div class="toast-message"><?php echo $message; ?></div>
                             </div>
                        </div>
                        
                    
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                        <div id="toast-container" class="toast-top-center">
                        	<div class="toast toast-error" aria-live="polite" style="">
                                <button type="button" class="toast-close-button" role="button">×</button>
                                <div class="toast-title">Distributor</div>
                                <div class="toast-message"><?php echo $error; ?></div>
                             </div>
                        </div>
                    <?php endif; ?>
                    <!-- start: alert Message -->
                    
         
                    

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!--<h4 class="card-title">Entered Form</h4>-->
                                <div class="basic-form" style="padding:1.88rem 1.81rem 0 1.81rem">
                                <form class="step-form-horizontal"  action="<?php echo base_url('index.php/zsm/approved_form'); ?>" enctype="multipart/form-data"  method="post" data-parsley-validate autocomplete="off">
                                            <div class="form-row">
                                                <div class="form-group col-md-4">
                                                    <!--<label>TSO</label>-->
                                                    <select name="asm" id="asm" class="form-control nice_select" required>
                                                        <option value="" selected="selected">Choose ASM...</option>
                                                        <?php foreach($asm as $val) { ?>
                                                            <option value="<?php echo $val['asm_number']; ?>" <?php echo ($val['asm_number'] == $asm_number?'selected':'');  ?>><?php echo $val['asm']; ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-1">
                                                    <button type="submit" class="btn btn-dark mb-2">Filter</button>
                                                </div>
                                                <div class="form-group col-md-1">
                                                    <a href="<?php echo base_url(); ?>index.php/zsm/approved_form" class="btn btn-success">Reset</a>
                                                </div>
                                            </div>
                                        </form>
                                 </div>
                                 
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                            	<th>S.NO</th>
                                                <th>Name</th>
                                                <th>Code</th>
                                                <th>Mobile</th>
                                                <th>Shop</th>
                                                <th>Address</th>
                                                <th>GST</th>
                                                <th>TSO Score</th>
                                                <th>VA verify</th>
                                                <!-- <th>VA Score</th> -->
                                                <th>Images</th>
                                                <th>Details</th>
                                                <!-- <th>Approval</th>  -->

                                            </tr>
                                        </thead>
                                        <tbody>
                                        	<?php foreach($distribution as $k => $val) { ?>
                                                <?php
                                                $get_va_score = $this->masters_model->get_table_row('va_score','distribution_id ',$val['id']);
                                                $col="";
                                                if(isset($get_va_score)){
                                                    if($get_va_score['score']!==$val['score'])
                                                {
                                                    $col='style="background: #ffe4e4;"';
                                                }
                                                }
                                                
                                                ?>
                                            <tr <?php echo $col;?>>
                                            	<td><?php echo $k+1; ?></td>
                                                <td><?php echo $val['name']; ?></td>
                                                <td><?php echo $val['distributor_code']; ?></td>
                                                <td><?php echo $val['mobile']; ?></td>
                                                <td><?php echo $val['shop_name']; ?></td>
                                                <td><?php echo $val['shop_address']; ?></td>
                                                <td><?php echo $val['gst']; ?></td>
                                                <td><?php echo $val['score']; ?></td>
                                                <?php if($val['va_review']==1){
                                                    ?>
                                                    <td style="color: green;"><?php echo "Verified";?></td>
                                                    <?php
                                                    }
                                                    else{
                                                        ?>
                                                        <td style="color: red;"><?php echo "Not Verified";?></td>
                                                        <?php
                                                        }; 
                                                ?>
                                                <!-- <td><?php echo $val['score_va']; ?></td> -->
                                                <td style="text-align: center;"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#imageview<?php echo $val['id'];?>">View</button>
                                                <?php
                                                    $d_id=$val['id'];
                                                    $get_images = $this->masters_model->get_images('asm_report_img','d_id',$d_id); 
                                                    $data['get_images'] = $get_images;
                                                    $counter = 0; 
                                                    if (is_array($get_images) && count($get_images) > 0) {
                                                        ?>
                                                        <br><br><b style="cursor:pointer;" data-toggle="modal" data-target="#imageview_asm_doc<?php echo $val['id'];?>">ASM Doc</b>
                                                        <?php
                                                    }
                                                ?>
                                                </td>
                                                <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#additionaview<?php echo $val['id'];?>">View</button></td>
                                                <!-- <td><button type="button" class="btn btn-danger" onclick="approve_action('<?php echo $val['id'];?>');">Reject</button></td> -->

                                            </tr>
                                  <!--Modal for additionaview-->
          							 <div class="modal fade" id="additionaview<?php echo $val['id'];?>">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Additional Information</h5>
                                                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                                </div>
                                                <div class="modal-body" style="padding-top:0;">
                                                <?php 
                                                $creator_row = $this->masters_model->get_table_row_condition('users','mobile',$val['created_by']);

                                                $get_distri = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','No. of Years of exp. In Distribution','points',$val['years_of_exp']);
												$get_busi = $this->masters_model->get_table_row_with_three_condition('additional_info','parameters','Existing Company Business','points',$val['existing_company'],'business',$creator_row[0]['business']);
												
                                                $get_capa = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Investment Capacity','points',$val['investment_capacity']);
												$get_soil = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Son of the Soil','points',$val['son_of_soil']);
												$get_vehicle = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Vehicle','points',$val['vehicle']);
												$get_godown = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Godown','points',$val['godown']);
												
                                                $get_va_score = $this->masters_model->get_table_row('va_score','distribution_id ',$val['id']);
												
												?>
                                                <div class="row" style="padding:12px 0;">
                                                    <div class="col-4">latitude: <?php echo $val['latitude']; ?></div>
                                                    <div class="col-4">longitude: <?php echo $val['longitude']; ?></div>
                                                    <div class="col-4">Business: <?php echo $creator_row[0]['business']; ?></div>
                                                </div>
                                                
                                               <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                                                    <div class="col-4">Parameters</div>
                                                    <div class="col-4">Slab</div>
                                                    <div class="col-2">TSO Points</div>
                                                    <!-- <div class="col-2">VA Points</div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">No. of Years of exp. In Distribution</div>
                                                    <div class="col-4"><?php echo $get_distri['slab']; ?></div>
                                                    <div class="col-2"><?php echo $val['years_of_exp']; ?></div>
                                                    <!-- <div class="col-2"><?php echo $get_va_score['years_of_exp']; ?></div> -->
                                                    
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#f3f3f3;">
                                                    <div class="col-4">Existing Company Business</div>
                                                    <div class="col-4"><?php echo $get_busi['slab']; ?></div>
                                                    <div class="col-2"><?php echo $val['existing_company']; ?></div>
                                                    <!-- <div class="col-2"><?php echo $get_va_score['existing_company']; ?></div> -->

                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">Investment Capacity</div>
                                                    <div class="col-4"><?php echo $get_capa['slab']; ?></div>
                                                    <div class="col-2"><?php echo $val['investment_capacity']; ?></div>
                                                    <!-- <div class="col-2"><?php echo $get_va_score['investment_capacity']; ?></div> -->

                                                </div>
                                                <div class="row" style="padding:8px 0; background:#f3f3f3;">
                                                    <div class="col-4">Son of the Soil</div>
                                                    <div class="col-4"><?php echo $get_soil['slab']; ?></div>
                                                    <div class="col-2"><?php echo $val['son_of_soil']; ?></div>
                                                    <!-- <div class="col-2"><?php echo $get_va_score['son_of_soil']; ?></div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">Vehicle</div>
                                                    <div class="col-4"><?php echo $get_vehicle['slab']; ?></div>
                                                    <div class="col-2"><?php echo $val['vehicle']; ?></div>
                                                    <!-- <div class="col-2"><?php echo $get_va_score['vehicle']; ?></div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#f3f3f3;">
                                                    <div class="col-4">Godown</div>
                                                    <div class="col-4"><?php echo $get_godown['slab']; ?></div>
                                                    <div class="col-2"><?php echo $val['godown']; ?></div>
                                                    <!-- <div class="col-2"><?php echo $get_va_score['godown']; ?></div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">Remark</div>
                                                    <div class="col-8"><?php echo $val['remark']; ?></div>
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">ASM Remark</div>
                                                    <div class="col-8"><?php echo $val['asm_remark']; ?></div>
                                                </div>
                                                <!-- <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">VA Remark</div>
                                                    <div class="col-8"><?php echo $get_va_score['remark']; ?></div>
                                                </div> -->
                                                
                                                <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                                                    <div class="col-4">SS Code</div>
                                                    <div class="col-4">RSP (SSFA Number)</div>
                                                    <div class="col-4">Type of SubD</div>
                                                </div>
                                                <div class="row" style="padding:12px 0; background:#fff;">
                                                    <div class="col-4"><?php echo $val['ss_code']; ?></div>
                                                    <div class="col-4"><?php echo $val['rst_ssta']; ?></div>
                                                    <div class="col-4"><?php echo $val['swd']; ?></div>
                                                </div>
                                                
                                                <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                                                    <div class="col-2">State</div>
                                                    <div class="col-2">City</div>
                                                    <div class="col-2">Town</div>
                                                    <div class="col-2">Pin Code</div>
                                                    <div class="col-2">Population</div>
                                                    <div class="col-2">Town Code</div>
                                                </div>
                                                <div class="row" style="padding:12px 0; background:#fff;">
                                                    <div class="col-2"><?php echo $val['shop_sate']; ?></div>
                                                    <div class="col-2"><?php echo $val['shop_city']; ?></div>
                                                    <div class="col-2"><?php echo $val['shop_town']; ?></div>
                                                    <div class="col-2"><?php echo $val['shop_zipcode']; ?></div>
                                                    <div class="col-2"><?php echo $val['population']; ?></div>
                                                    <div class="col-2"><?php echo $val['town_code']; ?></div>
                                                </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                              <!-- Modal end-->
                              
                              
                              <!-- image Modal -->
                              <div class="modal fade" id="imageview<?php echo $val['id'];?>">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Shop Images</h5>
                                            <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                          <div class="bootstrap-carousel">
                                            <div id="carouselExampleControls<?php echo $val['id'];?>" class="carousel slide" data-ride="carousel">
                                                <div class="carousel-inner">
                                                    <?php 
                                                    $d_id=$val['id'];
                                                    $get_images = $this->masters_model->get_images('shop_images','d_id',$d_id); 
                                                    $data['get_images'] = $get_images;
                                                    $counter = 0; 
                                                    if (is_array($get_images) && count($get_images) > 0) {
                                                    foreach($get_images as $img) {
                                                        
                                                    ?>
                                                    
                                                    <div class="carousel-item <?= ($counter == 0) ? "active" : "" ?>">
                                                      <img class="d-block w-100" src="<?php echo base_url('uploads/'.$img->shop_images.''); ?>">
                                                    </div>
                                                    <?php  $counter++; } } else { echo "No Images"; } ?> 
                                                </div>
                                                
                                                <a class="carousel-control-prev" href="#carouselExampleControls<?php echo $val['id'];?>" data-slide="prev"><span class="carousel-control-prev-icon"></span> <span class="sr-only">Previous</span> </a>
                                                <a class="carousel-control-next" href="#carouselExampleControls<?php echo $val['id'];?>"
                                                    data-slide="next"><span class="carousel-control-next-icon"></span> <span class="sr-only">Next</span></a>
                                            </div>
                                        </div>
                                      </div>
                                   </div>
                               </div>
                            </div>
                           <!-- image Modal ends -->
                           
                           <!-- img asm doc -->
                           <div class="modal fade" id="imageview_asm_doc<?php echo $val['id'];?>">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">ASM Image</h5>
                                            <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                          <div class="bootstrap-carousel">
                                            <div id="carouselExampleControls<?php echo $val['id'];?>" class="carousel slide" data-ride="carousel">
                                                <div class="carousel-inner">
                                                    <?php 
                                                    $d_id=$val['id'];
                                                    $get_images = $this->masters_model->get_images('asm_report_img','d_id',$d_id); 
                                                    $data['get_images'] = $get_images;
                                                    $counter = 0; 
                                                    if (is_array($get_images) && count($get_images) > 0) {
                                                    foreach($get_images as $img) {
                                                        
                                                    ?>
                                                    
                                                    <div class="carousel-item <?= ($counter == 0) ? "active" : "" ?>">
                                                      <img class="d-block w-100" src="<?php echo base_url('approved_doc_uploads/'.$img->image.''); ?>">
                                                    </div>
                                                    <?php  $counter++; } } else { echo "No Images"; } ?> 
                                                </div>
                                                
                                                <a class="carousel-control-prev" href="#carouselExampleControls<?php echo $val['id'];?>" data-slide="prev"><span class="carousel-control-prev-icon"></span> <span class="sr-only">Previous</span> </a>
                                                <a class="carousel-control-next" href="#carouselExampleControls<?php echo $val['id'];?>"
                                                    data-slide="next"><span class="carousel-control-next-icon"></span> <span class="sr-only">Next</span></a>
                                            </div>
                                        </div>
                                      </div>
                                   </div>
                               </div>
                            </div>
                           <!-- end img asm doc -->
                              
                              
                              
                              
                             
                                            <?php  } ?>
                                        </tbody>
                                       <!-- <tfoot>
                                            <tr>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Shop Name</th>
                                                <th>Shop License</th>
                                                <th>Years of exp</th>
                                                <th>Existing Company</th>
                                                <th>Investment Capacity</th>
                                                <th>Son of the Soil</th>
                                                <th>Vehicle</th>
                                                <th>Godown</th>
                                            </tr>
                                        </tfoot>-->
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Modal for approval-->
                <button type="button" class="btn btn-primary" id="approve_pop" data-toggle="modal" data-target="#approval" style="display:none;">Approval</button>

                <div class="modal fade" id="approval">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Action for this Form</h5>
                                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                            <form action="javascript:void(0);" enctype="multipart/form-data" data-parsley-validate method="post" autocomplete="off">	
                            <input type="hidden" name="id" id="id" class="form-control" value="">
                            <input type="hidden" id="type"> 
                            <!-- <button type="button" name="approval" id="app_btn" class="btn mb-1 btn-success">Approve</button> -->
                            <button type="button" name="reject" id="rej_btn" class="btn mb-1 btn-danger">Reject</button>

                                <div class="form_hid_action" style="display:none;">
                                <div class="form-group">
                                <label class="col-md-3 control-label" for="Department">Remarks</label>
                                <div class="col-md-12">
                                <textarea name="remarks" id="remarks" class="form-control"></textarea>
                                </div>

                                </div>
                                <button type="button" name="" id="submit_app_pop" class="btn mb-1 btn-success" style="float: right;">Submit</button>
                                </div>
                                    <p id="form_resp" style="display:none;"></p>
                            </form>
                        </div>
                    </div>
                </div>
                </div>
                <!-- image Modal approval -->

            </div>
            <!-- #/ container -->
        </div>

        
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by <a href="http://hemas.in/">Hemas.in</a> 2018</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="<?php echo asset_url();?>plugins/common/common.min.js"></script>
    <script src="<?php echo asset_url();?>js/custom.min.js"></script>
    <script src="<?php echo asset_url();?>js/settings.js"></script>
    <script src="<?php echo asset_url();?>js/gleek.js"></script>
    <script src="<?php echo asset_url();?>js/styleSwitcher.js"></script>

    <script src="<?php echo asset_url();?>new_add/js/pop_app_rej.js"></script>

    <script src="<?php echo asset_url();?>plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/tables/js/datatable-init/datatable-basic.min.js"></script>
    
    <script>
        var BASE_URL = "<?php echo base_url();?>index.php/"; 
		var ASSET_URL = "<?php echo asset_url();?>";

	 $(document).ready(function () {
		var  page="approved_form";

		if(page=="approved_form"){
			$(".approved_form").addClass("active");
		}

		});
		

		$('#toast-container').delay(5000).fadeOut('slow');	
		$(document).on("click", ".toast-close-button", function (e) {
			$('#toast-container').hide();
		});
		
	</script>
    <?php include('application/views/include/select_2_footer.php'); ?>

</body>

</html>