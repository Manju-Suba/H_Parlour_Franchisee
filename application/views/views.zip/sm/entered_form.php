<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>CK_SubD Entered Form</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo asset_url();?>images/logo.png">
    <!-- Custom Stylesheet -->
    <link href="<?php echo asset_url();?>plugins/toastr/css/toastr.min.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>plugins/jquery-steps/css/jquery.steps.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>css/style.css" rel="stylesheet">
    
    <?php include('application/views/include/select_2_head.php'); ?>
     <style>
		/*.nav-header .brand-logo a{ padding:0;}
		.nav-header .brand-logo a b img{ max-width:100%;}
		[data-sidebar-style="full"][data-layout="vertical"] .menu-toggle .nav-header .brand-logo a{ padding:0;}
		[data-nav-headerbg="color_1"] .nav-header{background-color:#fff;}
		.wizard > .steps > ul > li{ width:30%;}
		.wizard .content{ min-height:500px !important;}*/
		.card .card-body {    padding:0 0 1.88rem 0;}
	</style>

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
         <?php include('application/views/include/header.php'); ?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
         <?php include('application/views/include/sidebar.php'); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
               
            </div>
            <!-- row -->
            
            <!-- start: alert Message -->
                    <?php $message = $this->session->flashdata('message'); ?>
                    <?php $error = $this->session->flashdata('error'); ?>
                    <?php if (!empty($message)): ?>
                    	<div id="toast-container" class="toast-top-center">
                        	<div class="toast toast-success" aria-live="polite" style="">
                                <button type="button" class="toast-close-button" role="button">×</button>
                                <div class="toast-title">Distributor</div>
                                <div class="toast-message"><?php echo $message; ?></div>
                             </div>
                        </div>
                        
                    
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger ">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" style="color:#fff;">×</button>
                            <i class="fa fa-times-circle fa-fw fa-lg"></i>
                            <strong></strong><?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    <!-- start: alert Message -->
                    
         
                    

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!--<h4 class="card-title">Entered Form</h4>-->
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                            	<th>S.NO</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Shop</th>
                                                <th>Address</th>
                                                <th>GST</th>
                                                <th>TSO Score</th>
                                                <th>Approval</th>
                                                <th>Images</th>
                                                <th>Details</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	<?php foreach($distribution as $k => $val) { ?> 
                                            <tr>
                                            	<td><?php echo $k+1; ?></td>
                                                <td><?php echo $val['name']; ?></td>
                                                <td><?php echo $val['mobile']; ?></td>
                                                <td><?php echo $val['shop_name']; ?></td>
                                                <td><?php echo $val['shop_address']; ?></td>
                                                <td><?php echo $val['gst']; ?></td>
                                                <td><?php echo $val['score']; ?></td>
                                                <td style="font-size: 13px;"><span>ASM :</span>
                                                    <?php 
                                                    if($val['asm_approval']=="Approved"){
                                                        ?><b class="text-success">Approved</b><?php
                                                    }else if($val['asm_approval']=="Rejected"){
                                                        ?><b class="text-danger">Hold</b><?php
                                                    } 
                                                    else{
                                                        ?><b class="text-warning">Pending</b><?php
                                                    } 
                                                    ?>
                                                    <br>
                                                    <span>VA :</span>
                                                    <?php 
                                                    if($val['va_review']=="1"){
                                                        ?><b class="text-success">Reviewed</b><?php
                                                    } 
                                                    else{
                                                        ?><b class="text-warning">Pending</b><?php
                                                    } 
                                                    ?>
                                                     <br>
                                                    <span>SI :</span>
                                                    <?php 
                                                    if($val['distributor_code']!==""){
                                                        ?><b class="text-success">Reviewed</b><?php
                                                    } 
                                                    else{
                                                        ?><b class="text-warning">Pending</b><?php
                                                    } 
                                                    ?>
                                                </td>
                                                <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#basicModal<?php echo $val['id'];?>">View</button></td>
                                                <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong<?php echo $val['id'];?>">View</button></td>
                                            </tr>
                                  <!--Modal-->
          							 <div class="modal fade" id="exampleModalLong<?php echo $val['id'];?>">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Additional Information</h5>
                                                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                                </div>
                                                <div class="modal-body" style="padding-top:0;">
                                                <?php 

                                                $creator_row = $this->masters_model->get_table_row_condition('users','mobile',$val['created_by']);

												//$get_details = $this->masters_model->get_table_row('distribution','id',$val['id']);  
												$get_distri = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','No. of Years of exp. In Distribution','points',$val['years_of_exp']);
												$get_busi = $this->masters_model->get_table_row_with_three_condition('additional_info','parameters','Existing Company Business','points',$val['existing_company'],'business',$creator_row[0]['business']);
												
                                                $get_capa = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Investment Capacity','points',$val['investment_capacity']);
												$get_soil = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Son of the Soil','points',$val['son_of_soil']);
												$get_vehicle = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Vehicle','points',$val['vehicle']);
												$get_godown = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Godown','points',$val['godown']);
												
												?> 
                                                <div class="row" style="padding:12px 0;">
                                                    <div class="col-4">latitude: <?php echo $val['latitude']; ?></div>
                                                    <div class="col-4">longitude: <?php echo $val['longitude']; ?></div>
                                                    <div class="col-4">Business: <?php echo $creator_row[0]['business']; ?></div>
                                                </div>
                                                
                                               <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                                                    <div class="col-4">Parameters</div>
                                                    <div class="col-5">Slab</div>
                                                    <div class="col-3">Points</div>
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">No. of Years of exp. In Distribution</div>
                                                    <div class="col-5"><?php echo $get_distri['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['years_of_exp']; ?></div>
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#f3f3f3;">
                                                    <div class="col-4">Existing Company Business</div>
                                                    <div class="col-5"><?php echo $get_busi['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['existing_company']; ?></div>
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">Investment Capacity</div>
                                                    <div class="col-5"><?php echo $get_capa['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['investment_capacity']; ?></div>
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#f3f3f3;">
                                                    <div class="col-4">Son of the Soil</div>
                                                    <div class="col-5"><?php echo $get_soil['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['son_of_soil']; ?></div>
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">Vehicle</div>
                                                    <div class="col-5"><?php echo $get_vehicle['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['vehicle']; ?></div>
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#f3f3f3;">
                                                    <div class="col-4">Godown</div>
                                                    <div class="col-5"><?php echo $get_godown['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['godown']; ?></div>
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">Remark</div>
                                                    <div class="col-8"><?php echo $val['remark']; ?></div>
                                                </div>
                                                
                                                 <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                                                    <div class="col-4">SS Code</div>
                                                    <div class="col-4">RSP (SSFA Number)</div>
                                                    <div class="col-4">Type of SubD</div>
                                                </div>
                                                <div class="row" style="padding:12px 0; background:#fff;">
                                                    <div class="col-4"><?php echo $val['ss_code']; ?></div>
                                                    <div class="col-4"><?php echo $val['rst_ssta']; ?></div>
                                                    <div class="col-4"><?php echo $val['swd']; ?></div>
                                                </div>
                                                
                                                <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                                                    <div class="col-2">State</div>
                                                    <div class="col-2">City</div>
                                                    <div class="col-2">Town</div>
                                                    <div class="col-2">Pin Code</div>
                                                    <div class="col-2">Population</div>
                                                    <div class="col-2">Town Code</div>
                                                </div>
                                                <div class="row" style="padding:12px 0; background:#fff;">
                                                    <div class="col-2"><?php echo $val['shop_sate']; ?></div>
                                                    <div class="col-2"><?php echo $val['shop_city']; ?></div>
                                                    <div class="col-2"><?php echo $val['shop_town']; ?></div>
                                                    <div class="col-2"><?php echo $val['shop_zipcode']; ?></div>
                                                    <div class="col-2"><?php echo $val['population']; ?></div>
                                                    <div class="col-2"><?php echo $val['town_code']; ?></div>
                                                </div>
                                                
                                               
                                                
												
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                              <!-- Modal end-->
                              
                              
                              <!-- image Modal -->
                              <div class="modal fade" id="basicModal<?php echo $val['id'];?>">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Shop Images</h5>
                                            <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                          <div class="bootstrap-carousel">
                                            <div id="carouselExampleControls<?php echo $val['id'];?>" class="carousel slide" data-ride="carousel">
                                                <div class="carousel-inner">
                                                    <?php 
                                                    $d_id=$val['id'];
                                                    $get_images = $this->masters_model->get_images('shop_images','d_id',$d_id); 
                                                    $data['get_images'] = $get_images;
                                                    $counter = 0; 
                                                    if (is_array($get_images) && count($get_images) > 0) {
                                                    foreach($get_images as $img) {
                                                        
                                                    ?>
                                                    
                                                    <div class="carousel-item <?= ($counter == 0) ? "active" : "" ?>">
                                                      <img class="d-block w-100" src="<?php echo base_url('uploads/'.$img->shop_images.''); ?>">
                                                    </div>
                                                    <?php  $counter++; } } else { echo "No Images"; } ?> 
                                                </div>
                                                
                                                <a class="carousel-control-prev" href="#carouselExampleControls<?php echo $val['id'];?>" data-slide="prev"><span class="carousel-control-prev-icon"></span> <span class="sr-only">Previous</span> </a>
                                                <a class="carousel-control-next" href="#carouselExampleControls<?php echo $val['id'];?>"
                                                    data-slide="next"><span class="carousel-control-next-icon"></span> <span class="sr-only">Next</span></a>
                                            </div>
                                        </div>
                                      </div>
                                   </div>
                               </div>
                            </div>
                           <!-- image Modal ends -->
                              
                              
                              
                              
                             
                                            <?php  } ?>
                                        </tbody>
                                       <!-- <tfoot>
                                            <tr>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Shop Name</th>
                                                <th>Shop License</th>
                                                <th>Years of exp</th>
                                                <th>Existing Company</th>
                                                <th>Investment Capacity</th>
                                                <th>Son of the Soil</th>
                                                <th>Vehicle</th>
                                                <th>Godown</th>
                                            </tr>
                                        </tfoot>-->
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by <a href="http://hemas.in/">Hemas.in</a> 2018</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="<?php echo asset_url();?>plugins/common/common.min.js"></script>
    <script src="<?php echo asset_url();?>js/custom.min.js"></script>
    <script src="<?php echo asset_url();?>js/settings.js"></script>
    <script src="<?php echo asset_url();?>js/gleek.js"></script>
    <script src="<?php echo asset_url();?>js/styleSwitcher.js"></script>


    <script src="<?php echo asset_url();?>plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/tables/js/datatable-init/datatable-basic.min.js"></script>
    
    <script>
	 $(document).ready(function () {
		var  page="entered_form";

		if(page=="entered_form"){
			$(".entered_form").addClass("active");
		}

		});
	</script>
     

</body>

</html>