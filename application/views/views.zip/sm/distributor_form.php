<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>CK_SubD Distributor Form</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo asset_url();?>images/logo.png">
    <!-- Custom Stylesheet -->
    <link href="<?php echo asset_url();?>plugins/toastr/css/toastr.min.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>plugins/jquery-steps/css/jquery.steps.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>css/style.css" rel="stylesheet">

    <?php include('application/views/include/select_2_head.php'); ?>

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <?php include('application/views/include/header.php'); ?>
        
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include('application/views/include/sidebar.php'); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
               
            </div>
            <!-- row -->
            
            <!-- start: alert Message -->
                    <?php $message = $this->session->flashdata('message'); ?>
                    <?php $error = $this->session->flashdata('error'); ?>
                    <?php if (!empty($message)): ?>
                    	<div id="toast-container" class="toast-top-center">
                        	<div class="toast toast-success" aria-live="polite" style="">
                                <button type="button" class="toast-close-button" role="button">×</button>
                                <div class="toast-title">Distributor</div>
                                <div class="toast-message"><?php echo $message; ?></div>
                             </div>
                        </div>
                        
                    
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger ">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true" style="color:#fff;">×</button>
                            <i class="fa fa-times-circle fa-fw fa-lg"></i>
                            <strong></strong><?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    <!-- start: alert Message -->
                    

            <div class="container-fluid"> 
                <div class="row">
                    <div class="col-md-12">
                        <form class="step-form-horizontal" action="<?php echo base_url('index.php/sm/add_distribution'); ?>" enctype="multipart/form-data" id="step-form-horizontal"  data-parsley-validate method="post" autocomplete="off"> 
                            <div>
                                <h4>Basic Details</h4>
                                <section>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="">SubD Proprietor Name</label>
                                                <input type="text" name="name" class="form-control low_to_upper_case" placeholder="SubD Proprietor Name" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="">SubD Mobile</label>
                                                <input type="text" name="mobile" id="mobile" maxlength="13" oninput="mobileValid();" class="form-control" placeholder="SubD Mobile" required>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="">SubD Firm Name</label>
                                                <input type="text" name="shop_name" id="shop_name" class="form-control low_to_upper_case" placeholder="SubD Firm Name" required>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="">SubD Firm Landline</label>
                                                <input type="text" name="shop_landline" id="shop_landline" maxlength="13" oninput="mobileValid_2();" class="form-control" placeholder="SubD Firm Landline">
                                            </div>
                                        </div> 
                                        
                                        <div class="col-lg-6"> 
                                            <div class="form-group">
                                                <label for="">SubD Firm Address</label>
                                                <input type="text" name="shop_address" class="form-control low_to_upper_case" placeholder="SubD Firm Address" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-6"> 
                                        	<div class="form-group">
                                                <label for="">State</label>
                                            	 <select name="shop_sate" id="shop_sate" class="form-control nice_select" required>
                                                    <option value="">Select State</option>
                                                     <?php foreach($sates as $sates ){ ?>
														<option value="<?php echo $sates['state_name']; ?>"><?php echo $sates['state_name'] ?></option>
													<?php } ?>
                                                </select>
                                             </div>
                                        </div> 
                                        <div class="col-lg-4">
                                        	<div class="form-group">
                                                <label for="">District</label>
                                            	<select id="shop_city" name="shop_city" class="form-control nice_select" required>      
                                                    <option value="">Select District</option>
                                                </select> 
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                        	<div class="form-group">
                                                <label for="">Town</label>
                                            	<select id="shop_town" name="shop_town" class="form-control nice_select" required>      
                                                    <option value="">Select Town</option>
                                                </select>
                                             </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label for="">Town Code</label>
                                                <input type="text" name="town_code" id="town_code" class="form-control" placeholder="Town Code" readonly>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label for="">Population</label>
                                                <input type="text" name="population" id="population" class="form-control" placeholder="Population" readonly/>
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label for="">GST Number</label>
                                                <input type="text" name="gst" id="gst" class="form-control low_to_upper_case" placeholder="GST Number">
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                        	<div class="form-group">
                                                <label for="">Shop Image</label>
                                                <input type="file" id="fileupload" multiple="multiple" name="image_name[]" class="form-control" value="" required >
                                                <div class="validation" style="display:none;"> Upload Max 5 Files allowed </div>
                                            </div>
                                            <!-- <div class="custom-file">
                                                    <input type="file" class="custom-file-input">
                                                    <label class="custom-file-label">Choose Images</label>
                                                </div> -->
                                       </div>
                                           
                                       <div class="col-lg-3" style="text-align: center;top: 30px;">
                                                <button type="button" id="check_avail" class="btn mb-1 btn-success">Check Availability</button>
                                           </div>
                                           <div class="col-lg-10">
                                             <div id="avai_main" style="display:none; color:red;"><span id="mob_avai">* &nbsp; Mobile Number</span> <span id="name_avai">&nbsp; * &nbsp; Shop Name</span> <span id="gst_avai">&nbsp; * &nbsp; GST</span> &nbsp; Already Exists</div>
                                           </div> 

                                           <div class="col-lg-12">
                                           </div> 


                                           
                                    </div>
                                </section>
                                <h4>Additional Details</h4> 
                                <section>
                                    <div class="row">
                                        <div class="form-group col-lg-4">
                                                <label>No. of Years of exp. In Distribution</label>
                                                <select name="years_of_exp" id="years_of_exp" class="form-control" required>
                                                    <option value="">Choose...</option>
                                                     <?php foreach($distribution as $dist ){ ?>
														<option value="<?php echo $dist['points']; ?>"><?php echo $dist['slab'] ?></option>
													<?php } ?>
                                                </select>
                                        </div>
                                        <div class="form-group col-lg-4">
                                                <label>Existing Company Business</label>
                                                <select name="existing_company" id="existing_company" class="form-control" required>
                                                	<option value="">Choose...</option>
                                                     <?php foreach($business as $busi ){ ?>
														<option value="<?php echo $busi['points']; ?>"><?php echo $busi['slab'] ?></option>
													<?php } ?>
                                                </select>
                                        </div>
                                        <div class="form-group col-lg-4">
                                                <label>Investment Capacity</label>
                                                <select name="investment_capacity" id="investment_capacity" class="form-control" required>
                                                	<option value="">Choose...</option>
                                                     <?php foreach($capacity as $capa ){ ?>
														<option value="<?php echo $capa['points']; ?>"><?php echo $capa['slab'] ?></option>
													<?php } ?>
                                                </select>
                                        </div>
                                        <div class="form-group col-lg-4">
                                                <label>Son of the Soil</label>
                                                <select name="son_of_soil" id="son_of_soil" class="form-control" required>
                                                    <option value="">Choose...</option>
                                                    <?php foreach($soil as $soil ){ ?>
														<option value="<?php echo $soil['points']; ?>"><?php echo $soil['slab'] ?></option>
													<?php } ?>
                                                </select>
                                        </div>
                                        <div class="form-group col-lg-4">
                                                <label>Vehicle</label>
                                                <select name="vehicle" id="vehicle" class="form-control" required>
                                                    <option value="">Choose...</option>
                                                     <?php foreach($vehicle as $vehicle ){ ?>
														<option value="<?php echo $vehicle['points']; ?>"><?php echo $vehicle['slab'] ?></option>
													<?php } ?>
                                                </select>
                                        </div>
                                        <div class="form-group col-lg-4">
                                                <label>Godown</label>
                                                <select name="godown" id="godown" class="form-control" required>
                                                    <option value="">Choose...</option>
                                                    <?php foreach($godown as $godown ){ ?>
														<option value="<?php echo $godown['points']; ?>"><?php echo $godown['slab'] ?></option>
													<?php } ?>
                                                </select>
                                        </div>
                                        <div class="form-group col-lg-12">
                                                <label>Remark If Any</label>
                                               <input type="text" name="remark" class="form-control low_to_upper_case" placeholder="">
                                               <br><p id="geolocation"></p>
                                               <input type="hidden" name="latitude" id="latitude" class="form-control" >
                                       		   <input type="hidden" name="longitude" id="longitude" class="form-control" >
                                        </div>
                                        
                                        
                                    </div>
                                </section>
                                
                                <h4>Confirmation</h4>
                                <section>
                                    <div class="row">
                                    	<div class="col-lg-4">
                                        	<div class="form-group">
                                            	<label>SS Code</label>
                                                <input type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"  name="ss_code" class="form-control" placeholder="SS Code"  maxlength="7" pattern="\d{7}" title="Please enter exactly 7 digits" required>
                                              </div>
                                        </div>
                                        <div class="col-lg-4">
                                             <div class="form-group">
                                             	<label>RSP (SSFA Number)</label>
                                                <input type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" name="rst_ssta" class="form-control" placeholder="RSP (SSFA Number)"  maxlength="10" pattern="\d{10}" title="Please enter exactly 10 digits" required>
                                              </div>
                                        </div>
                                    	<div class="form-group col-lg-4">
                                                <label>Type of SubD</label>
                                                <select name="swd" id="swd" class="form-control" required>
                                                    <option value="">Choose...</option>
														<option value="New">New</option>
                                                        <option value="Replacement">Replacement</option>
                                                </select>
                                        </div>
                                        
                                        <div class="col-12" style="text-align:center; margin-top:50px; margin-bottom:20px;">
                                            <h2>Are you sure that you want to submit the form ?</h2>
                                        </div>
                                    </div>
                                    <input type="hidden" id="save_status" name="save_status" value="0">
                                    <div class="col-md-12">
                                        <div class="row">

                                        <div class="col-md-4">
                                        </div>
                                        <div class="col-md-4" style="text-align:center;">
                                                <button type="button" id="save_form" class="btn mb-1 btn-primary"><b>Save</b></button>
                                                <button type="submit" id="form_submit_btn" class="btn mb-1 btn-success"><b>Submit</b></button>
                                        </div>
                                        <div class="col-md-4">
                                        </div>

                                           
                                        </div>
                                    </div>
                                    
                                </section>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by <a href="http://hemas.in/">Hemas.in</a> 2018</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="<?php echo asset_url();?>plugins/common/common.min.js"></script>
    <script src="<?php echo asset_url();?>js/custom.min.js"></script>
    <script src="<?php echo asset_url();?>js/settings.js"></script>
    <script src="<?php echo asset_url();?>js/gleek.js"></script>
    <script src="<?php echo asset_url();?>js/styleSwitcher.js"></script>


    <script src="<?php echo asset_url();?>plugins/jquery-steps/build/jquery.steps.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="<?php echo asset_url();?>js/plugins-init/jquery-steps-init.js"></script>
    
    <!-- Toastr -->
    <script src="<?php echo asset_url();?>plugins/toastr/js/toastr.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/toastr/js/toastr.init.js"></script>

    <!-- added new -->
    <script src="<?php echo asset_url();?>new_add/js/distributor_form.js"></script>

    <?php include('application/views/include/select_2_footer.php'); ?>

     <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
    	<script>
		$(document).on("click", ".toast-close-button", function (e) {
			$('#toast-container').hide();
		});

        function mobileValid(){
            var textInput = document.getElementById("mobile").value;
            textInput = textInput.replace(/[^0-9]/g, "");
            document.getElementById("mobile").value = textInput;
        }
        function mobileValid_2(){
            var textInput = document.getElementById("shop_landline").value;
            textInput = textInput.replace(/[^0-9]/g, "");
            document.getElementById("shop_landline").value = textInput;
        }
		
		//window.onbeforeunload = function(){
		// return 'Are you sure you want to leave?';
		//};
		$('#step-form-horizontal').data('serialize',$('#step-form-horizontal').serialize()); // On load save form current state

		$(window).bind('beforeunload', function(e){
			if($('#step-form-horizontal').serialize()!=$('#step-form-horizontal').data('serialize'))return true;
			else e=null; // i.e; if form state change show warning box, else don't show it.
			 
		});
		
		$(document).on("submit", "form", function(event){
				// disable warning
				$(window).off('beforeunload');
			});
		
		
		$('.toast-success').delay(5000).fadeOut('slow');
		
		 $(document).on("click", "#check_avail", function (e) {
			 
                var mobile = $('#mobile').val();
				var shop_name = $('#shop_name').val();
				var gst = $('#gst').val();
                var ajax_url = '<?php echo base_url(); ?>';
                $.ajax({
                    url: ajax_url + 'sm/get_availability',
					data : {'mobile':mobile,'shop_name':shop_name,'gst':gst},
                    type: 'post',
					dataType:"JSON",
                    success: function (data) {
						console.log(data);
						if(data.mobile_cnt >= 1){
							$('#avai_main').show();
							$('#mob_avai').show();
							$('#avai_main').delay(5000).fadeOut('slow');
						}else{
							
							$('#mob_avai').hide();
						}
						
						if(data.name_cnt >= 1){
							$('#avai_main').show();
							$('#name_avai').show();
							$('#avai_main').delay(5000).fadeOut('slow');
						}else{
							
							$('#name_avai').hide();
						}
						if(data.gst_cnt >= 1){
							$('#avai_main').show();
							$('#gst_avai').show();
							$('#avai_main').delay(5000).fadeOut('slow');
						}else{
							
							$('#gst_avai').hide();
						}

                    }
                });
            });
			
			
			
		 $(document).ready(function () {
		var  page="distributor_form";

		if(page=="distributor_form"){
			$(".distributor_form").addClass("active");
		}

		});
		
		
		
		////get the input and the file list
//		$('#fileupload').change(function(){
//		   //get the input and the file list
//		   var input = document.getElementById('fileupload');
//		   if(input.files.length>5){
//			   $('.validation').css('display','block');
//			   document.getElementById("fileupload").value = "";
//			   $('#fileupload').prop('required', true);
//		   }
//		 
//		   else{
//			    $('#fileupload').removeAttr('required');
//			   $('.validation').css('display','none');
//		   }
//		});
			
			
		// get Latitude and Longitude	
		var x = document.getElementById("geolocation");	
		$(document).ready(function() {
		$("a").click(function(){
			 if (navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(showPosition);
			  } else { 
				x.innerHTML = "Geolocation is not supported by this browser.";
			  }
			})
		});
		
		function showPosition(position) {
		  x.innerHTML = "Latitude: " + position.coords.latitude + 
		  "<br>Longitude: " + position.coords.longitude;
		  $('#latitude').val(position.coords.latitude);
		  $('#longitude').val(position.coords.longitude);
		}
/////////////////

		// get city
		jQuery(document).on('change', 'select#shop_sate', function (e) {
			e.preventDefault();
			var stateID = jQuery(this).val();
			getCityList(stateID);
		 
		});
		
		// function get All Cities
		function getCityList(stateID) {
			var ajax_url = '<?php echo base_url(); ?>';
			$.ajax({
				url: ajax_url + 'sm/getcities',
				type: 'post',
				data: {stateID: stateID},
				dataType: 'json',
				beforeSend: function () {
					jQuery('select#shop_city').find("option:eq(0)").html("Please wait..");
				},
				complete: function () {
					// code
				},
				success: function (json) {
					var options = '';
					options +='<option value="">Select District</option>';
					for (var i = 0; i < json.length; i++) {
						options += '<option value="' + json[i].district_name + '">' + json[i].district_name + '</option>';
					}
					jQuery("select#shop_city").html(options);
                    // town list
                    var options = '';
					options +='<option value="">Select Town</option>';
					jQuery("select#shop_town").html(options);
		 
				},
				error: function (xhr, ajaxOptions, thrownError) {
					console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				}
			});
		}
		
		
		
		
		// get town
		jQuery(document).on('change', 'select#shop_city', function (e) {
			e.preventDefault();
			var cityID = jQuery(this).val();
			getTownList(cityID);
		 
		});

        
		
		// function get All town
		function getTownList(cityID) {
			var ajax_url = '<?php echo base_url(); ?>';
			$.ajax({
				url: ajax_url + 'sm/gettowns',
				type: 'post',
				data: {cityID: cityID},
				dataType: 'json',
				beforeSend: function () {
					jQuery('select#shop_town').find("option:eq(0)").html("Please wait..");
				},
				complete: function () {
					// code
				},
				success: function (json) {
					var options = '';
					options +='<option value="">Select Town</option>';
					for (var i = 0; i < json.length; i++) {
						options += '<option value="' + json[i].town_name + '">' + json[i].town_name + '</option>';
					}
					jQuery("select#shop_town").html(options);
		 
				},
				error: function (xhr, ajaxOptions, thrownError) {
					console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				}
			});
		}
		
		
		
		// get zip code
		jQuery(document).on('change', 'select#shop_town', function (e) {
			e.preventDefault();
			var townID = jQuery(this).val();
			getZipList(townID);
		 
		});
		
		// function get All town
		function getZipList(townID) {
			var ajax_url = '<?php echo base_url(); ?>';
			$.ajax({
				url: ajax_url + 'sm/getzip',
				type: 'post',
				data: {townID: townID},
				dataType: 'json',
				success: function (json) {
					//alert(json.zip_code);
					console.log(json);
					$('#town_code').val(json.town_code);
				},
			});

            $.ajax({
				url: ajax_url + 'sm/get_population',
				type: 'post',
				data: {townID: townID},
				dataType: 'json',
				success: function (json) {
					//alert(json.zip_code);
					console.log(json);
					$('#population').val(json.population);
				},
			});
		}


		</script>
        <script>
            $(".low_to_upper_case").keyup(function(){
                $(this).val($(this).val().toUpperCase());
            })
        </script>

</body>

</html>