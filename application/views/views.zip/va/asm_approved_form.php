<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>CK_SubD Entered Form</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo asset_url();?>images/logo.png">
    <!-- Custom Stylesheet -->
    <link href="<?php echo asset_url();?>plugins/toastr/css/toastr.min.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>plugins/jquery-steps/css/jquery.steps.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
    <?php include('application/views/include/select_2_head.php'); ?>
     <style>
		/*.nav-header .brand-logo a{ padding:0;}
		.nav-header .brand-logo a b img{ max-width:100%;}
		[data-sidebar-style="full"][data-layout="vertical"] .menu-toggle .nav-header .brand-logo a{ padding:0;}
		[data-nav-headerbg="color_1"] .nav-header{background-color:#fff;}
		.wizard > .steps > ul > li{ width:30%;}
		.wizard .content{ min-height:500px !important;}*/
        .wizard > .content > .body select.error {
			background: rgb(251, 227, 228);
			border: 1px solid #fbc2c4;
			color: #8a1f11;
		}
		.card .card-body {    padding:0 0 1.88rem 0;}
        .opacity-30-no-click{
            pointer-events: none;
            opacity: 75%;
        }
	</style>

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
         <?php include('application/views/include/header.php'); ?> 
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
         <?php include('application/views/include/sidebar.php'); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
               
            </div>
            <!-- row -->
            
            <!-- start: alert Message -->
                    <?php $message = $this->session->flashdata('message'); ?>
                    <?php $error = $this->session->flashdata('error'); ?>
                    <?php if (!empty($message)): ?>
                    	<div id="toast-container" class="toast-top-center">
                        	<div class="toast toast-success" aria-live="polite" style="">
                                <button type="button" class="toast-close-button" role="button">×</button>
                                <div class="toast-title">Distributor</div>
                                <div class="toast-message"><?php echo $message; ?></div>
                             </div>
                        </div>
                        
                    
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                        <div id="toast-container" class="toast-top-center">
                        	<div class="toast toast-error" aria-live="polite" style="">
                                <button type="button" class="toast-close-button" role="button">×</button>
                                <div class="toast-title">Distributor</div>
                                <div class="toast-message"><?php echo $error; ?></div>
                             </div>
                        </div>
                    <?php endif; ?>
                    <!-- start: alert Message --> 
                    
         
                    

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!--<h4 class="card-title">Entered Form</h4>-->
                                <div class="basic-form" style="padding:1.88rem 1.81rem 0 1.81rem">
                                 <form class="step-form-horizontal"  action="<?php echo base_url('index.php/va/asm_approved_form'); ?>" enctype="multipart/form-data"  method="post" data-parsley-validate autocomplete="off">
                                 	<div class="form-row">
                                        <div class="form-group col-md-4">
                                            <!--<label>TSO</label>-->
                                            <select name="asm" id="asm" class="form-control nice_select" required>
                                                <option value="" selected="selected">Choose ASM...</option>
                                                <?php foreach($asm as $val) { ?>
                                                	<option value="<?php echo $val['asm_number']; ?>" <?php echo ($val['asm_number'] == $asm_number?'selected':'');  ?>><?php echo $val['asm']; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                         <div class="form-group col-md-1">
                                         	<button type="submit" class="btn btn-dark mb-2">Filter</button>
                                         </div>
                                         <div class="form-group col-md-1">
                                         	<a href="<?php echo base_url(); ?>va/asm_approved_form" class="btn btn-success">Reset</a>
                                         </div>
                                      </div>
                                 </form>
                                 </div>
                                 
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                            	<th>S.NO</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Shop</th>
                                                <th>Address</th>
                                                <th>GST</th>
                                                <th>TSO Score</th>
                                                <th>Images</th>
                                                <th>Details</th>
                                                <th>Action</th>
                                                <!-- <th>VA Approval</th>  -->
                                            </tr>
                                        </thead> 
                                        <tbody>
                                        	<?php foreach($distribution as $k => $val) { ?>
                                            <tr>
                                            	<td><?php echo $k+1; ?></td>
                                                <td><?php echo $val['name']; ?></td>
                                                <td><?php echo $val['mobile']; ?></td>
                                                <td><?php echo $val['shop_name']; ?></td>
                                                <td><?php echo $val['shop_address']; ?></td>
                                                <td><?php echo $val['gst']; ?></td>
                                                <td><?php echo $val['score']; ?></td>
                                                <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#imageview<?php echo $val['id'];?>">View</button></td>
                                                <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#additionaview_<?php echo $val['id'];?>">View</button></td>
                                                <td><button class="btn btn-primary btn-mini " onclick="edit_business_pop('<?php echo $val['id'];?>');">
                                <i class="fa fa-pencil"></i>
                            </button>  </td>
                                                <!-- <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#approval<?php echo $val['id']; ?>">Approval</button></td> -->
                                            </tr>
                                  <!--Modal for additionaview-->
          							 <div class="modal fade" id="additionaview_<?php echo $val['id'];?>">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Additional Information</h5>
                                                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                                </div>
                                                <div class="modal-body" style="padding-top:0;">
                                                <?php 
                                                $creator_row = $this->masters_model->get_table_row_condition('users','mobile',$val['created_by']);

												//$get_details = $this->masters_model->get_table_row('distribution','id',$val['id']);  
												$get_distri = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','No. of Years of exp. In Distribution','points',$val['years_of_exp']);
												$get_busi = $this->masters_model->get_table_row_with_three_condition('additional_info','parameters','Existing Company Business','points',$val['existing_company'],'business',$creator_row[0]['business']);
												
                                                $get_capa = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Investment Capacity','points',$val['investment_capacity']);
												$get_soil = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Son of the Soil','points',$val['son_of_soil']);
												$get_vehicle = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Vehicle','points',$val['vehicle']);
												$get_godown = $this->masters_model->get_table_row_with_two_condition('additional_info','parameters','Godown','points',$val['godown']);
												
												?>
                                                <div class="row" style="padding:12px 0;">
                                                    <div class="col-4">latitude: <?php echo $val['latitude']; ?></div>
                                                    <div class="col-4">longitude: <?php echo $val['longitude']; ?></div>
                                                    <div class="col-4">Business: <?php echo $creator_row[0]['business']; ?></div>
                                                </div>
                                                
                                               <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                                                    <div class="col-4">Parameters</div>
                                                    <div class="col-5">TSO Review</div>
                                                    <div class="col-2">TSO Points</div>
                                                    <!-- <div class="col-3">My Review</div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">No. of Years of exp. In Distribution</div>
                                                    <div class="col-5"><?php echo $get_distri['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['years_of_exp']; ?></div>
                                                    <!-- <div class="col-3">
                                                    <select name="years_of_exp" id="years_of_exp_<?php echo $val['id'];?>" class="form-control" required>
                                                        <option value="">Choose...</option>
                                                        <?php foreach($distribution_sel_box as $dist ){ ?>
                                                            <option value="<?php echo $dist['points']; ?>"><?php echo $dist['slab'] ?></option>
                                                        <?php } ?>
                                                    </select> 
                                                    </div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#f3f3f3;">
                                                    <div class="col-4">Existing Company Business</div>
                                                    <div class="col-5"><?php echo $get_busi['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['existing_company']; ?></div>
                                                    <!-- <div class="col-3">
                                                    <select name="existing_company" id="existing_company_<?php echo $val['id'];?>" class="form-control" required>
                                                        <option value="">Choose...</option>
                                                        <?php foreach($business as $busi ){ ?>
                                                            <option value="<?php echo $busi['points']; ?>"><?php echo $busi['slab'] ?></option>
                                                        <?php } ?>
                                                    </select>
                                                    </div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">Investment Capacity</div>
                                                    <div class="col-5"><?php echo $get_capa['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['investment_capacity']; ?></div>
                                                    <!-- <div class="col-3">
                                                    <select name="investment_capacity" id="investment_capacity_<?php echo $val['id'];?>" class="form-control" required>
                                                        <option value="">Choose...</option>
                                                        <?php foreach($capacity as $capa ){ ?>
                                                            <option value="<?php echo $capa['points']; ?>"><?php echo $capa['slab'] ?></option>
                                                        <?php } ?>
                                                    </select>
                                                    </div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#f3f3f3;">
                                                    <div class="col-4">Son of the Soil</div>
                                                    <div class="col-5"><?php echo $get_soil['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['son_of_soil']; ?></div>
                                                    <!-- <div class="col-3">
                                                    <select name="son_of_soil" id="son_of_soil_<?php echo $val['id'];?>" class="form-control" required>
                                                        <option value="">Choose...</option>
                                                        <?php foreach($soil as $soil ){ ?>
                                                            <option value="<?php echo $soil['points']; ?>"><?php echo $soil['slab'] ?></option>
                                                        <?php } ?>
                                                    </select>
                                                    </div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">Vehicle</div>
                                                    <div class="col-5"><?php echo $get_vehicle['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['vehicle']; ?></div>
                                                    <!-- <div class="col-3">
                                                    <select name="vehicle" id="vehicle_<?php echo $val['id'];?>" class="form-control" required>
                                                        <option value="">Choose...</option>
                                                        <?php foreach($vehicle as $vehicle ){ ?>
                                                            <option value="<?php echo $vehicle['points']; ?>"><?php echo $vehicle['slab'] ?></option>
                                                        <?php } ?>
                                                    </select>
                                                    </div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#f3f3f3;">
                                                    <div class="col-4">Godown</div>
                                                    <div class="col-5"><?php echo $get_godown['slab']; ?></div>
                                                    <div class="col-3"><?php echo $val['godown']; ?></div>
                                                    <!-- <div class="col-3">
                                                    <select name="godown" id="godown_<?php echo $val['id'];?>" class="form-control" required>
                                                        <option value="">Choose...</option>
                                                        <?php foreach($godown as $godown ){ ?>
                                                            <option value="<?php echo $godown['points']; ?>"><?php echo $godown['slab'] ?></option>
                                                        <?php } ?>
                                                    </select>
                                                    </div> -->
                                                </div>
                                                <div class="row" style="padding:8px 0; background:#fff;">
                                                    <div class="col-4">Remark</div>
                                                    <div class="col-8"><?php echo $val['remark']; ?></div>
                                                </div>
                                                
                                                <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                                                    <div class="col-4">SS Code</div> 
                                                    <div class="col-4">RSP (SSFA Number)</div>
                                                    <div class="col-4">Type of SubD</div>
                                                </div>
                                                <div class="row" style="padding:12px 0; background:#fff;">
                                                    <div class="col-4"><?php echo $val['ss_code']; ?></div>
                                                    <div class="col-4"><?php echo $val['rst_ssta']; ?></div>
                                                    <div class="col-4"><?php echo $val['swd']; ?></div>
                                                </div>
                                                
                                                <div class="row" style="padding:12px 0; background:#F3F1FA; font-weight:bold; font-size:14px;">
                                                    <div class="col-2">State</div>
                                                    <div class="col-2">City</div>
                                                    <div class="col-2">Town</div>
                                                    <div class="col-2">Pin Code</div>
                                                    <div class="col-2">Population</div>
                                                    <div class="col-2">Town Code</div> 
                                                </div>
                                                <div class="row" style="padding:12px 0; background:#fff;">
                                                    <div class="col-2"><?php echo $val['shop_sate']; ?></div>
                                                    <div class="col-2"><?php echo $val['shop_city']; ?></div>
                                                    <div class="col-2"><?php echo $val['shop_town']; ?></div>
                                                    <div class="col-2"><?php echo $val['shop_zipcode']; ?></div>
                                                    <div class="col-2"><?php echo $val['population']; ?></div>
                                                    <div class="col-2"><?php echo $val['town_code']; ?></div>
                                                </div>

                                                <!-- <div class="form-group">
                                                <label>Remarks</label> 
                                                <textarea class="form-control" name="remark" id="remark_<?php echo $val['id'];?>"></textarea>
                                                </div> -->

                                                <!-- <div class="form-group col-md-4" style="float:right;">
                                                    <button type="button" class="btn btn-info btn-lg btn-block" onclick="pop_va_edit_score_submit('<?php echo $val['id'];?>')" id="pop_va_edit_score_submit"><i class="fas fa-prescription-bottle-alt"></i>&nbsp;
                                                    Submit Review  
                                                    </button> 
                                                </div> -->

                                                <p id="va_rev_resp" style="display:none;"></p>
                                                
												
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                              <!-- Modal end-->

                        <?php include('application/views/include/asm_approved_form_va_log_pop.php'); ?> 
 
                              
                              
                              <!-- image Modal -->
                              <div class="modal fade" id="imageview<?php echo $val['id'];?>">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Shop Images</h5>
                                            <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                          <div class="bootstrap-carousel">
                                            <div id="carouselExampleControls<?php echo $val['id'];?>" class="carousel slide" data-ride="carousel">
                                                <div class="carousel-inner">
                                                    <?php 
                                                    $d_id=$val['id'];
                                                    $get_images = $this->masters_model->get_images('shop_images','d_id',$d_id); 
                                                    $data['get_images'] = $get_images;
                                                    $counter = 0; 
                                                    if (is_array($get_images) && count($get_images) > 0) {
                                                    foreach($get_images as $img) {
                                                        
                                                    ?>
                                                    
                                                    <div class="carousel-item <?= ($counter == 0) ? "active" : "" ?>">
                                                      <img class="d-block w-100" src="<?php echo base_url('uploads/'.$img->shop_images.''); ?>">
                                                    </div>
                                                    <?php  $counter++; } } else { echo "No Images"; } ?> 
                                                </div>
                                                
                                                <a class="carousel-control-prev" href="#carouselExampleControls<?php echo $val['id'];?>" data-slide="prev"><span class="carousel-control-prev-icon"></span> <span class="sr-only">Previous</span> </a>
                                                <a class="carousel-control-next" href="#carouselExampleControls<?php echo $val['id'];?>"
                                                    data-slide="next"><span class="carousel-control-next-icon"></span> <span class="sr-only">Next</span></a>
                                            </div>
                                        </div>
                                      </div>
                                   </div>
                               </div>
                            </div>
                           <!-- image Modal ends -->
                           
                           
                           <!-- Modal for approval-->
                           <div class="modal fade" id="approval<?php echo $val['id'];?>">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Approval for this Form</h5>
                                            <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                        <form action="javascript:void(0);" enctype="multipart/form-data" data-parsley-validate method="post" autocomplete="off">	
                                        <input type="hidden" name="id" id="id" class="form-control" value="<?php echo $val['id'];?>">
                                        <input type="hidden" id="type">
                                        <button type="button" name="approval" id="app_btn" class="btn mb-1 btn-success">Approve</button>
                                        <button type="button" name="reject" id="rej_btn" class="btn mb-1 btn-danger">Reject</button>

                                            <div class="form_hid_action" style="display:none;">
                                            <div class="form-group">
                                            <label class="col-md-3 control-label" for="Department">Remarks</label>
                                             <div class="col-md-12">
                                            <textarea name="remarks" id="remarks" class="form-control"></textarea>
                                            </div>

                                            </div>
                                            <button type="button" name="" id="submit_app_pop" class="btn mb-1 btn-success" style="float: right;">Submit</button>
                                            </div>
                                                <p id="form_resp" style="display:none;"></p>
                                        </form> 
                                    </div>
                                </div>
                            </div>
                            </div>
                           <!-- image Modal approval -->
                              
                              
                              
                              
                             
                                            <?php  } ?>
                                        </tbody>
                                       <!-- <tfoot>
                                            <tr>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Shop Name</th>
                                                <th>Shop License</th>
                                                <th>Years of exp</th>
                                                <th>Existing Company</th>
                                                <th>Investment Capacity</th>
                                                <th>Son of the Soil</th>
                                                <th>Vehicle</th>
                                                <th>Godown</th>
                                            </tr>
                                        </tfoot>-->
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by <a href="http://hemas.in/">Hemas.in</a> 2018</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="<?php echo asset_url();?>new_add/js/asm_approved_form_va_log.js"></script>

    
    <script src="<?php echo asset_url();?>plugins/common/common.min.js"></script>
    <script src="<?php echo asset_url();?>js/custom.min.js"></script>
    <script src="<?php echo asset_url();?>js/settings.js"></script>
    <script src="<?php echo asset_url();?>js/gleek.js"></script>
    <script src="<?php echo asset_url();?>js/styleSwitcher.js"></script>

    <script src="<?php echo asset_url();?>plugins/jquery-steps/build/jquery.steps.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="<?php echo asset_url();?>js/plugins-init/jquery-steps-init.js"></script>


    <script src="<?php echo asset_url();?>plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/tables/js/datatable-init/datatable-basic.min.js"></script>
    <?php include('application/views/include/select_2_footer.php'); ?>
    
    <script>
        var BASE_URL = "<?php echo base_url();?>index.php/";
		var ASSET_URL = "<?php echo asset_url();?>";

	    $(document).ready(function () {
		var  page="asm_approved_form";

		if(page=="asm_approved_form"){
			$(".asm_approved_form").addClass("active");
		}

		});
		

		$('#toast-container').delay(5000).fadeOut('slow');	
		$(document).on("click", ".toast-close-button", function (e) {
			$('#toast-container').hide();
		});

        // get city
		jQuery(document).on('change', 'select#shop_sate', function (e) {
			e.preventDefault();
			var stateID = jQuery(this).val();
			getCityList(stateID);
		 
		});

        function mobileValid(){
            var textInput = document.getElementById("mobile").value;
            textInput = textInput.replace(/[^0-9]/g, "");
            document.getElementById("mobile").value = textInput;
        }

        function mobileValid_2(){
            var textInput = document.getElementById("shop_landline").value;
            textInput = textInput.replace(/[^0-9]/g, "");
            document.getElementById("shop_landline").value = textInput;
        }
		
		// function get All Cities
		function getCityList(stateID) {
			var ajax_url = '<?php echo base_url(); ?>';
			$.ajax({
				url: ajax_url + 'va/getcities', 
				type: 'post',
				data: {stateID: stateID},
				dataType: 'json',
				beforeSend: function () {
					jQuery('select#shop_city').find("option:eq(0)").html("Please wait..");
				},
				complete: function () {
					// code
				},
				success: function (json) {
					var options = '';
					options +='<option value="">Select District</option>';
					for (var i = 0; i < json.length; i++) {
						options += '<option value="' + json[i].district_name + '">' + json[i].district_name + '</option>';
					}
					jQuery("select#shop_city").html(options);
                    // town list
                    var options = '';
					options +='<option value="">Select Town</option>';
					jQuery("select#shop_town").html(options);
		 
				},
				error: function (xhr, ajaxOptions, thrownError) {
					console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				}
			});
		}
		

        // get town
		jQuery(document).on('change', 'select#shop_city', function (e) {
			e.preventDefault();
			var cityID = jQuery(this).val();
			getTownList(cityID);
		 
		});
		
		// function get All town
		function getTownList(cityID) {
			var ajax_url = '<?php echo base_url(); ?>';
			$.ajax({
				url: ajax_url + 'va/gettowns',
				type: 'post',
				data: {cityID: cityID},
				dataType: 'json',
				beforeSend: function () {
					jQuery('select#shop_town').find("option:eq(0)").html("Please wait..");
				},
				complete: function () {
					// code
				},
				success: function (json) {
					var options = '';
					options +='<option value="">Select Town</option>';
					for (var i = 0; i < json.length; i++) {
						options += '<option value="' + json[i].town_name + '">' + json[i].town_name + '</option>';
					}
					jQuery("select#shop_town").html(options);
		 
				},
				error: function (xhr, ajaxOptions, thrownError) {
					console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				}
			});
		}
		

        // get zip code
		jQuery(document).on('change', 'select#shop_town', function (e) {
			e.preventDefault();
			var townID = jQuery(this).val(); 
			getZipList(townID);
		 
		});
		
		// function get All town
		function getZipList(townID) {
			var ajax_url = '<?php echo base_url(); ?>';
			$.ajax({
				url: ajax_url + 'va/getzip',
				type: 'post',
				data: {townID: townID},
				dataType: 'json',
				success: function (json) {
					//alert(json.zip_code);
					console.log(json);
					$('#town_code').val(json.town_code);
				},
				
			});
            $.ajax({
				url: ajax_url + 'tso/get_population',
				type: 'post',
				data: {townID: townID},
				dataType: 'json',
				success: function (json) {
					//alert(json.zip_code);
					console.log(json);
					$('#population').val(json.population);
				},
			});

		}

		
	</script>
     <script>
        $(".low_to_upper_case").keyup(function(){
            $(this).val($(this).val().toUpperCase());
        })
    </script>
     

</body>

</html>