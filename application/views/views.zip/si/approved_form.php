<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>CK_SubD Entered Form</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo asset_url();?>images/logo.png">
    <!-- Custom Stylesheet -->
    <link href="<?php echo asset_url();?>plugins/toastr/css/toastr.min.css" rel="stylesheet">
    
    <link href="<?php echo asset_url();?>plugins/jquery-steps/css/jquery.steps.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>plugins/tables/css/datatable/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="<?php echo asset_url();?>css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
     <style>
		/*.nav-header .brand-logo a{ padding:0;}
		.nav-header .brand-logo a b img{ max-width:100%;}
		[data-sidebar-style="full"][data-layout="vertical"] .menu-toggle .nav-header .brand-logo a{ padding:0;}
		[data-nav-headerbg="color_1"] .nav-header{background-color:#fff;}
		.wizard > .steps > ul > li{ width:30%;}
		.wizard .content{ min-height:500px !important;}*/
        .wizard > .content > .body select.error {
			background: rgb(251, 227, 228);
			border: 1px solid #fbc2c4;
			color: #8a1f11;
		}
		.card .card-body {    padding:0 0 1.88rem 0;}
        .opacity-30-no-click{
            pointer-events: none;
            opacity: 75%;
        }
        .dt-buttons{
            padding-left: 25px;
        }
        .dt-buttons button{
            cursor: pointer;
        }
	</style>

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
         <?php include('application/views/include/header.php'); ?> 
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
         <?php include('application/views/include/sidebar.php'); ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
               
            </div>
            <!-- row -->
            
            <!-- start: alert Message -->
                    <?php $message = $this->session->flashdata('message'); ?>
                    <?php $error = $this->session->flashdata('error'); ?>
                    <?php if (!empty($message)): ?>
                    	<div id="toast-container" class="toast-top-center">
                        	<div class="toast toast-success" aria-live="polite" style="">
                                <button type="button" class="toast-close-button" role="button">×</button>
                                <div class="toast-title">Distributor</div>
                                <div class="toast-message"><?php echo $message; ?></div>
                             </div>
                        </div>
                        
                    
                    <?php endif; ?>

                    <?php if (!empty($error)): ?>
                        <div id="toast-container" class="toast-top-center">
                        	<div class="toast toast-error" aria-live="polite" style="">
                                <button type="button" class="toast-close-button" role="button">×</button>
                                <div class="toast-title">Distributor</div>
                                <div class="toast-message"><?php echo $error; ?></div>
                             </div>
                        </div>
                    <?php endif; ?>
                    <!-- start: alert Message -->
                    
         
                    

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!--<h4 class="card-title">Entered Form</h4>-->
                                <div class="basic-form" style="padding:1.88rem 1.81rem 0 1.81rem">
                                 <form class="step-form-horizontal" id="filter_form"  action="javascript:void(0)" enctype="multipart/form-data"  method="post" data-parsley-validate autocomplete="off">
                                 	<div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label>From Date</label>
                                            <input type="date" class="form-control" name="from_date" id="from_date">
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>To Date</label>
                                            <input type="date" class="form-control" name="to_date" id="to_date">
                                        </div>

                                         <div class="form-group col-md-1">
                                         	<button type="submit" class="btn btn-dark mb-2">Filter</button>
                                         </div>
                                         <div class="form-group col-md-1">
                                         	<button type="reset" class="btn btn-success">Reset</button>
                                         </div>
                                         <div class="form-group col-md-1">
                                         </div>

                                        <div class="col-sm-1">
											<button type="button" class="btn btn-primary" id="upload_inv_num_file" >
											<i class="fa fa-upload" aria-hidden="true"></i>&nbsp;Upload
											</button>
										</div>
                                      </div>
                                 </form>
                                 </div>
                                 
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration" id="list_tbl">
                                        <thead>
                                            <tr>
                                            	<th>S.NO</th>
                                                <th>Name</th>
                                                <th>Code</th>
                                                <th>Mobile</th>
                                                <th>Shop</th>
                                                <th>Address</th>
                                                <th>GST</th>
                                                <th>TSO Score</th>
                                                <th>Images</th>
                                                <th>Details</th>
                                                <th>Action</th>
                                                <!-- <th>VA Approval</th>  -->
                                                <!-- hidden col -->
                                                <th>Software_ID</th>
                                                <th>Distributor Code</th>
                                                <th>Distributor Customer Code</th>
                                                <th>TYPE</th>
                                                <th>SS Name</th>
                                                <th>SS CITY</th>
                                                <th>SS PINCODE</th>
                                                <th>SUB CODE</th>
                                                <th>Sub Stockiest Name</th>
                                                <th>Beat/Town Name</th>
                                                <th>Mobile No</th>
                                                <th>Phone Num</th>
                                                <th>E MAIL ID</th>
                                                <th>Customer Address1</th>
                                                <th>Customer Address2</th>
                                                <th>Customer Address3</th>
                                                <th>GSTIN STATE</th>
                                                <th>GSTIN Number</th>
                                                <th>PAN Number</th>
                                                <th>GST STATE NAME</th>
                                                <th>SM Name</th>
                                                <th>Mobile Number</th>
                                                <th>CODE</th>
                                                <th>SALES ROUTE</th>
                                                <th>DELIVERY ROUTE</th>


                                            </tr>
                                        </thead> 
                                        <tbody>
                                            
                                        </tbody>
                                       <!-- <tfoot>
                                            <tr>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Shop Name</th>
                                                <th>Shop License</th>
                                                <th>Years of exp</th>
                                                <th>Existing Company</th>
                                                <th>Investment Capacity</th>
                                                <th>Son of the Soil</th>
                                                <th>Vehicle</th>
                                                <th>Godown</th>
                                            </tr>
                                        </tfoot>-->
                                    </table>
                                </div>

                        <?php include('application/views/include/va_approved_form_si_log_pop.php'); ?> 

                        <?php include('application/views/include/view_detail_pop.php'); ?>
                        <?php include('application/views/include/image_view_pop.php'); ?>
                        
                        <?php include('application/views/include/asm_image_view_pop.php'); ?>
                        <?php include('application/views/include/si_upload_pop.php'); ?>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright &copy; Designed & Developed by <a href="http://hemas.in/">Hemas.in</a> 2018</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="<?php echo asset_url();?>new_add/js/va_approved_form_si_log.js"></script>

    
    <script src="<?php echo asset_url();?>plugins/common/common.min.js"></script>
    <script src="<?php echo asset_url();?>js/custom.min.js"></script>
    <script src="<?php echo asset_url();?>js/settings.js"></script>
    <script src="<?php echo asset_url();?>js/gleek.js"></script>
    <script src="<?php echo asset_url();?>js/styleSwitcher.js"></script>

    <script src="<?php echo asset_url();?>plugins/jquery-steps/build/jquery.steps.min.js"></script>
    <script src="<?php echo asset_url();?>plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="<?php echo asset_url();?>js/plugins-init/jquery-steps-init.js"></script>

    <script src="<?php echo asset_url();?>new_add/js/detail_pop.js"></script> 

    <script src="<?php echo asset_url();?>cdn/jquery-3.5.1.js"></script>
        <script src="<?php echo asset_url();?>cdn/1.10.25/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo asset_url();?>cdn/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
        <script src="<?php echo asset_url();?>cdn/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
		<script src="<?php echo asset_url();?>cdn/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="<?php echo asset_url();?>cdn/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script src="<?php echo asset_url();?>cdn/buttons/1.7.1/js/buttons.html5.min.js"></script>
        <script src="<?php echo asset_url();?>cdn/buttons/1.7.1/js/buttons.print.min.js"></script>


    <script>
        var BASE_URL = "<?php echo base_url();?>index.php/";
		var ASSET_URL = "<?php echo asset_url();?>";

	    $(document).ready(function () {
		var  page="asm_approved_form";

		if(page=="asm_approved_form"){
			$(".asm_approved_form").addClass("active");
		}

		});
		

		$('#toast-container').delay(5000).fadeOut('slow');	
		$(document).on("click", ".toast-close-button", function (e) {
			$('#toast-container').hide();
		});

        // get city
		jQuery(document).on('change', 'select#shop_sate', function (e) {
			e.preventDefault();
			var stateID = jQuery(this).val();
			getCityList(stateID);
		 
		});
		
		// function get All Cities
		function getCityList(stateID) {
			var ajax_url = '<?php echo base_url(); ?>';
			$.ajax({
				url: ajax_url + 'va/getcities',
				type: 'post',
				data: {stateID: stateID},
				dataType: 'json',
				beforeSend: function () {
					jQuery('select#shop_city').find("option:eq(0)").html("Please wait..");
				},
				complete: function () {
					// code
				},
				success: function (json) {
					var options = '';
					options +='<option value="">Select City</option>';
					for (var i = 0; i < json.length; i++) {
						options += '<option value="' + json[i].city_id + '">' + json[i].city_name + '</option>';
					}
					jQuery("select#shop_city").html(options);
		 
				},
				error: function (xhr, ajaxOptions, thrownError) {
					console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				}
			});
		}
		

        // get town
		jQuery(document).on('change', 'select#shop_city', function (e) {
			e.preventDefault();
			var cityID = jQuery(this).val();
			getTownList(cityID);
		 
		});
		
		// function get All town
		function getTownList(cityID) {
			var ajax_url = '<?php echo base_url(); ?>';
			$.ajax({
				url: ajax_url + 'va/gettowns',
				type: 'post',
				data: {cityID: cityID},
				dataType: 'json',
				beforeSend: function () {
					jQuery('select#shop_town').find("option:eq(0)").html("Please wait..");
				},
				complete: function () {
					// code
				},
				success: function (json) {
					var options = '';
					options +='<option value="">Select Town</option>';
					for (var i = 0; i < json.length; i++) {
						options += '<option value="' + json[i].town_id + '">' + json[i].town_name + '</option>';
					}
					jQuery("select#shop_town").html(options);
		 
				},
				error: function (xhr, ajaxOptions, thrownError) {
					console.log(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
				}
			});
		}
		

        // get zip code
		jQuery(document).on('change', 'select#shop_town', function (e) {
			e.preventDefault();
			var townID = jQuery(this).val(); 
			getZipList(townID);
		 
		});
		
		// function get All town
		function getZipList(townID) {
			var ajax_url = '<?php echo base_url(); ?>';
			$.ajax({
				url: ajax_url + 'va/getzip',
				type: 'post',
				data: {townID: townID},
				dataType: 'json',
				success: function (json) {
					//alert(json.zip_code);
					console.log(json);
					$('#shop_zipcode').val(json.zip_code);
				},
				
			});
		}

		
	</script>
     <script>
        $(".low_to_upper_case").keyup(function(){
             $(this).val($(this).val().toUpperCase());
        })
     </script>

</body>

</html>